/*eslint-env node*/

//------------------------------------------------------------------------------
// node.js starter application for Bluemix
//------------------------------------------------------------------------------

// This application uses express as its web server
// for more info, see: http://expressjs.com
var express    = require('express');        // call express
var app        = express();                 // define our app using express
var bodyParser = require('body-parser');
// var  fs = require('fs');
// //var  PDFParser = require("pdf2json");
// var download = require('download-file');
// var path = require('path');
// var waitOn = require('wait-on');
// var pdfreader = require("pdfreader");



var cfenv = require('cfenv');

// create a new express server
var app = express();
var appEnv = cfenv.getAppEnv();
var port = 8085;

// serve the files out of ./public as our main files
//app.use(express.static(__dirname + '/public'));

// get the app environment from Cloud Foundry



app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodiesz
app.post('/insights', function(req, res) {

var appData = req.body.appData;
console.log(appData);
var docs = req.body.docs;
console.log(docs);

var check = [];

var nDocs = docs.length;
var nparams = appData.param.length;

for(i = 0; i<nDocs; i++){

  var docOne = docs[i];
  console.log("docOne "+docOne);


  for(j=0; j<nparams; j++){

   var paramOne = appData.param[j];


   if(paramOne==='name'){

     if(docOne.name.toUpperCase() === appData.name.toUpperCase())
   {


   }else{

     element = "{"+docOne.doc+":"+paramOne+"}";
     check.push(element);

   }


   }

  // console.log("paramOne "+docOne.name);

if(paramOne==='dob'){



  var d1 = new Date(stringToDate(docOne.dob,"dd/mm/yyyy","/"));
  var d2 = new Date(stringToDate(appData.dob,"dd/mm/yyyy","/"));

 // console.log("Dates "+dates.compare(d1,d2))

     if( d1.getTime() === d2.getTime() )
   {


   }else{

     element = "{"+docOne.doc+":"+paramOne+"}";
     check.push(element);

   }


   }

   



  }

  console.log(check);






}



res.send(check);


  
    
});


function stringToDate(_date,_format,_delimiter)
{
            var formatLowerCase=_format.toLowerCase();
            var formatItems=formatLowerCase.split(_delimiter);
            var dateItems=_date.split(_delimiter);
            var monthIndex=formatItems.indexOf("mm");
            var dayIndex=formatItems.indexOf("dd");
            var yearIndex=formatItems.indexOf("yyyy");
            var month=parseInt(dateItems[monthIndex]);
            month-=1;
            var formatedDate = new Date(dateItems[yearIndex],month,dateItems[dayIndex]);
            return formatedDate;
}



// start server on the specified port and binding host
app.listen(port, '0.0.0.0', function() {
  // print a message when the server starts listening
  console.log("server starting on " + appEnv.url);
});
